<?php
session_start();

$state = $county = $municipality = $selected = "";
function clean_data($txt)
{
    $txt = trim($txt);
    $txt = htmlspecialchars($txt);
    return $txt;
}

function testAllKey($arr, $post_keys)
{
    foreach ($arr as $key) {
        $k = strtolower(trim($key));
        $k = preg_replace('/\s+/', '_', $k);
        $k = preg_replace('/[^a-zA-Z0-9_ ]+/', '', $k);
        // $exist = false;
        // foreach ($post_keys as $value) {
        //     // echo var_dump($k) . "\n";
        //     if ($k == $value) {
        //         $exist = true;
        //         break;
        //     }
        // }
        if (!in_array($k, $post_keys)) {
            http_response_code(403);
            exit("Incomplete data send: No $k");
        }
    }
    return true;
}

if (
    isset($_SESSION['state']) && !empty($_SESSION['state']) &&
    isset($_SESSION['county']) && !empty($_SESSION['county']) &&
    isset($_SESSION['municipality']) && !empty($_SESSION['municipality']) &&
    isset($_SESSION['selected']) && !empty($_SESSION['selected']) &&
    isset($_SESSION['array']) && !empty($_SESSION['array']) &&
    isset($_SESSION['headers']) && !empty($_SESSION['headers']) &&
    isset($_SESSION['site']) && !empty($_SESSION['site']) &&
    isset($_SESSION['error_rows']) && isset($_SESSION['success_rows'])
) {
    $error_rows = $_SESSION['error_rows'];
    $success_rows = $_SESSION['success_rows'];
    $array = (array) $_SESSION['array'];
    $headers = (array) $_SESSION['headers'];
    $count_array = count($array);
    $site = $_SESSION['site'];
} else {
    header('location: datasource.php');
}


if ($_SERVER['REQUEST_METHOD'] === "POST") {
    if (isset($_POST['type']) && !empty($_POST['type'])) {
        $type = clean_data($_POST['type']);
        if ($type === "skip") {
            header('location: datasource.php');
        } else if ($type === "try again") {
            if (
                isset($_POST['type']) && !empty($_POST['type']) && testAllKey($headers, array_keys($_POST))
            ) {
                if ($success_rows === $count_array) {
                    header('location: datasource.php');
                }
                //filter array
                $filter = [];
                foreach ($_POST as $key => $value) {
                    if (!is_array($value)) continue;
                    $count = count($value);
                    for ($i = 0; $i < $count; $i++) {
                        $filter[$i] = $filter[$i] ?? [];
                        array_push($filter[$i], $value[$i]);
                    }
                }

                // http_response_code(403);
                // exit(print_r($filter));

                $_SESSION['array'] = $filter;
                $_SESSION['last_index'] = -1;
                $_SESSION['success_rows'] = 0;
                $_SESSION['error_rows'] = [];
                $_SESSION['try_again'] = true;
            } else {
                http_response_code(403);
                exit('Invalid data!');
            }
        }
    }
} else {
    header('location: datasource.php');
}
